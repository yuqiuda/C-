﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 倒计时应用
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int nums;
        public Point mouseOff;
        public bool leftFlag;
        int year;
        int month;
        int day;
        int h;
        int m;
        int s;

        private void my_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseOff = new Point(-e.X, -e.Y); //得到变量的值
                leftFlag = true;                  //点击左键按下时标注为true;
            }
        }

        private void my_MouseMove(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                Point mouseSet = Control.MousePosition;
                mouseSet.Offset(mouseOff.X, mouseOff.Y); //设置移动后的位置
                Location = mouseSet;
            }
        }

        private void my_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                leftFlag = false;//释放鼠标后标注为false;
            }
        }

        public void LoadSchedule()
        {
            int numbers = 0;
            try
            {
                if (File.Exists(".\\日程.txt"))
                {
                    //读取文件
                    FileStream fs = new FileStream("日程.txt", FileMode.Open, FileAccess.Read);
                    StreamReader rd = new StreamReader(fs, Encoding.Default);
                    String line;
                    while ((line = rd.ReadLine()) != null)
                    {
                        numbers++;
                        switch(numbers)
                        {
                            case 1:
                                if (line == "1") { 
                                    timer1.Enabled = true;
                                }
                                if (line == "0") { 
                                    timer1.Enabled = false;
                                    this.lb_CutDown.Text = "倒计时已关闭";
                                }
                                break;
                            case 2:
                                year = int.Parse(line);
                                break;
                            case 3:
                                month = int.Parse(line);
                                break;
                            case 4:
                                day = int.Parse(line);
                                break;
                            case 5:
                                h = int.Parse(line);
                                break;
                            case 6:
                                m = int.Parse(line);
                                break;
                            case 7:
                                s = int.Parse(line);
                                break;
                            case 8:
                                this.lb_Event.Text = line;
                                break;
                        }

                    }
                    rd.Close();
                    this.lb_Time.Text = year.ToString() + "年" + month.ToString() + "月" + day.ToString() + "日";
                }
                else
                {
                    MessageBox.Show("日程文件不存在。。。");
                }
            }
            catch
            {
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadSchedule();
            窗口始终在前ToolStripMenuItem.Checked = true;
            toolStripMenuItem11.Checked = true;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.1;
            toolStripMenuItem2.Checked = true;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.2;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = true;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.3;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = true;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.4;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = true;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.5;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = true;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.6;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = true;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.7;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = true;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.8;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = true;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.9;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = true;
            toolStripMenuItem11.Checked = false;
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            this.Opacity = 1.0;
            toolStripMenuItem2.Checked = false;
            toolStripMenuItem3.Checked = false;
            toolStripMenuItem4.Checked = false;
            toolStripMenuItem5.Checked = false;
            toolStripMenuItem6.Checked = false;
            toolStripMenuItem7.Checked = false;
            toolStripMenuItem8.Checked = false;
            toolStripMenuItem9.Checked = false;
            toolStripMenuItem10.Checked = false;
            toolStripMenuItem11.Checked = true;
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog()==DialogResult.OK)
            {
                foreach (Control s in this.Controls)
                {
                    if(s is Label)
                    {
                        Label t = (Label)s;
                        if (t.Name != "label4")
                            t.ForeColor = colorDialog1.Color;
                    }
                }
            }
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            foreach (Control s in this.Controls)
            {
                if (s is Label)
                {
                    Label t = (Label)s;
                    if (t.Name != "label4")
                        t.ForeColor = Color.Yellow;
                }
            }
        }

        private void OnTimer(object sender, EventArgs e)
        {
            string str = year.ToString() + "-" + month.ToString() + "-" + day.ToString() + " " + h.ToString() + ":" + m.ToString() + ":" + s.ToString();
            DateTime dt1 = Convert.ToDateTime(str);
            DateTime dt2 = DateTime.Now;
            TimeSpan tm = dt1 - dt2;
            this.lb_CutDown.Text = tm.Days + "天" + tm.Hours + "小时" + tm.Minutes + "分" + tm.Seconds + "秒";
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            LoadSchedule();
        }

        private void setTopMost(object sender, EventArgs e)
        {
            this.TopMost = !this.TopMost;
            窗口始终在前ToolStripMenuItem.Checked = !窗口始终在前ToolStripMenuItem.Checked;
        }

    }
}
